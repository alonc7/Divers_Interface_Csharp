﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Diving_Manage_System
{
    internal class DivingSite
    {
        public string name { get; set; }
        public string address { get; set; }
        public Country country { get; set; }
        public string deep { get; set; }
        public string length { get; set; }
        public string waterType { get; set; }

        public DivingSite(string name, string address, Country country, string deep, string length, string waterType)
        {
            this.name = name;
            this.address = address;
            this.country = country;
            this.deep = deep;
            this.length = length;
            this.waterType = waterType;
        }
    }
}
