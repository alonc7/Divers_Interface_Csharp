﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Diving_Manage_System
{
    internal class Country
    {
        public string name { get; set; }
        public string regulation { get; set; }
        public Country(string name, string regulation)
        {
            this.name = name;
            this.regulation = regulation;
        }

    }
}
