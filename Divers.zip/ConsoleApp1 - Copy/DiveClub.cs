﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diving_Manage_System
{
    internal class DiveClub : Country
    {
        public int id = 1000;
        public new string name { get; set; }
        public string contact { get; set; }
        public string city { get; set; }
        public string street { get; set; }
        public string phoneNumber { get; set; }
        public string email { get; set; }
        public string website { get; set; }
        public Country countryName { get; set; }


        public DiveClub(string name, string contact, string city, string street, string phoneNumber, string email, string website, Country countryName)
            : base(countryName.name, countryName.regulation)
        {
            this.id++;
            this.name = name;
            this.contact = contact;
            this.city = city;
            this.street = street;
            this.phoneNumber = phoneNumber;
            this.email = email;
            this.website = website;
            this.countryName = countryName;
        }
        public void SetId(int id)
        {
            this.id = id;
        }
        public int getId() { return this.id; }
    }
}
