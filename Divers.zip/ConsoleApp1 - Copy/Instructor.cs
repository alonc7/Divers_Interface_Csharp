﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diving_Manage_System
{
    internal class Instructor : Diver
    {
        DiveClub[] club = null;
        DateTime start = DateTime.Now;
        DateTime end = DateTime.Now;
        public Instructor(string id,string firstName, string lastName, string username, string password, DateTime birthdate, DiveClub[] club, DateTime start, DateTime end) : base(id,firstName, lastName, username, password, birthdate)
        {
            this.club = club;
            this.start = start;
            this.end = end;
        }
    }
}
