﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diving_Manage_System
{
    internal class Gear
    {
        public string name { get; set; }
        public int amount { get; set; }
        public string note { get; set; }
        

        public Gear(string name, int amount, string note)
        {
            this.name = name;
            this.amount = amount;
            this.note = note;
        }
    }
}

