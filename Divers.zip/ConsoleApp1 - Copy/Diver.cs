﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Diving_Manage_System
{
    internal class Diver
    {
        protected string id = "";
        protected string firstName = "";
        protected string lastName = "";
        protected string username = "";
        protected string password = "";
        protected DateTime birthDate = new DateTime();
         

        public Diver(string id, string firstName, string lastName, string username, string password, DateTime birthDate)
        {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.birthDate = birthDate;
        }
        public override string ToString()
        {
            return $"{firstName} {lastName} ,{id}\n";
        }
        public string GetId() { return id; }
        public string GetPass() { return password; }
        public string GetFirstName()
        {
            return firstName;
        }
    }
}
