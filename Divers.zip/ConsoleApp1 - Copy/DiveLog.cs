﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diving_Manage_System
{
    internal class DiveLog
    {
        public int id { get; set; }
        public DiveClub club { get; set; }
        public DateTime divingDate { get; set; }
        public TimeSpan startTime { get; set; }
        public TimeSpan endTime { get; set; }
        public string waterTemp { get; set; }
        public string waterStatus { get; set; }
        public Instructor instructor { get; set; }
        public List<Diver> divers { get; set; }
        public Gear[] gears { get; set; }
        public int idGenerate = 1;
        public DiveLog(DiveClub club, DateTime divingDate, TimeSpan startTime, TimeSpan endTime, string waterTemp, string waterStatus, Instructor instructor, List<Diver> divers, Gear[] gears = null)
        {
            this.id = idGenerate++;
            this.club = club;
            this.divingDate = divingDate;
            this.startTime = startTime;
            this.endTime = endTime;
            this.waterTemp = waterTemp;
            this.waterStatus = waterStatus;
            this.instructor = instructor;
            this.divers = divers;
            this.gears = gears;
        }

        public void SetSeaStatus(string status)
        {

        }
    }


}
