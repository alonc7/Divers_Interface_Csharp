﻿using Diving_Manage_System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Security.Claims;

namespace ConsoleApp1
{
    internal class Program
    {
        public static List<Diver> diverList = new List<Diver>(); // list of all divers created
        public static Dictionary<string, Diver> registeredDivers = new Dictionary<string, Diver>(); // dictionary by id and diver. of all registered divers 
        private static Dictionary<string, string> clubs = new Dictionary<string, string>();
        private static Dictionary<string, string[]> gearInDive = new Dictionary<string, string[]>();
        private static List<Diver> diversInDive = new List<Diver>();
        public static string mainDiver = "NULL";
        public static string clubName = "NULL";
        public static int divePartners = 0;
        static void Main(string[] args)
        {
            Dictionary<int, string> gears = new Dictionary<int, string>() {{1,"KNIFE" },
{2,"COMPASS" },
{3, "MILKSHAKE" },
{4, "HOOK" },
{5,"FLAIR" },
{6,"GAS_MASK" },
{7,"OXYIGEN_BOTTLE"},
{8,"DIVE_SUIT" },
{ 9,"CAMERA"} };
            Country israel = new Country("Israel", "In order to dive as a certified diver you must:\r\n1.be 12 years old and above\r\n2.Own Personal diving certification\r\n3.have a Diving insurance\r\n4.dived in the last six months");
            DiveClub diveClub1 = new DiveClub("OceanExplorers", "contact", "Eilat", "E(in)li co(ach)ohen", "1700707070", "Ocean@gmail.com", "www.Ocean-Explorers.com", israel);
            DiveClub[] worksAt = new DiveClub[1] { diveClub1 };
            Instructor masterDiver = new Instructor("111111", "david", "mizrahi", "david", "111111", DateTime.Parse("1990-11-04"), worksAt, DateTime.Parse("2010-11-04"), DateTime.Parse("2011-07-01"));
            Diver alon = new Diver("313233", "Alon", "Kochman", "alon", "313233090", DateTime.Parse("1995-04-19"));
            Diver yuval = new Diver("424344", "Yuval", "Feldman", "yuval", "424344090", DateTime.Parse("1995-05-24"));
            DivingSite uniqe = new DivingSite("somwhere", "anywhere", israel, "28", "120", "salt");
            diverList.Add(alon);
            diverList.Add(yuval);
            diverList.Add(masterDiver);
            registeredDivers.Add(masterDiver.GetId(), masterDiver);
            registeredDivers.Add(alon.GetId(), alon);
            registeredDivers.Add(yuval.GetId(), yuval);

            ShowMenu();
            int select = int.Parse(Console.ReadLine());

            while (select != 0)
            {
                while (select != 0)
                {
                    switch (select)
                    {
                        case (0):
                            return;
                        case (1):
                            if (Login())
                            {
                                while (true)
                                {
                                    Console.Clear();
                                    ShowDiverMenu();
                                    int diveSelect = int.Parse(Console.ReadLine());
                                    switch (diveSelect)
                                    {
                                        case (1):
                                            if (ValidAddDive())
                                            {
                                                Console.WriteLine("Add dive club or partner.");
                                                break;
                                            }
                                            Console.WriteLine($"You'r diving in Eilat israel");
                                            string diveSiteName = "Eilat";
                                            Console.WriteLine("Enter tide: low , or high?");
                                            string tide = Console.ReadLine();
                                            Console.WriteLine("Enter temperature: ");
                                            string waterTemp = Console.ReadLine();
                                            Console.WriteLine("Enter Year of dive");
                                            int yearOfDive = int.Parse(Console.ReadLine());
                                            Console.Write("month: ");
                                            int monthOfDive = int.Parse(Console.ReadLine());
                                            Console.Write("day: ");
                                            int dayOfDive = int.Parse(Console.ReadLine());
                                            DateTime dateOfDive = new DateTime(yearOfDive, monthOfDive, dayOfDive);
                                            while (yearOfDive < 1903 || monthOfDive < 1 || monthOfDive > 12 || dayOfDive < 1 || dayOfDive > 31)
                                            {
                                                Console.WriteLine("* Dive date input was not in correct format");
                                                yearOfDive = int.Parse(Console.ReadLine());
                                                Console.Write("month: ");
                                                monthOfDive = int.Parse(Console.ReadLine());
                                                Console.Write("day: ");
                                                dayOfDive = int.Parse(Console.ReadLine());
                                                dateOfDive = new DateTime(yearOfDive, monthOfDive, dayOfDive);
                                            }
                                            Console.WriteLine($"Date added successfuly {dayOfDive}/{monthOfDive}/{yearOfDive} press enter");
                                            Console.WriteLine("Enter start time:");
                                            int startTimeHours = int.Parse(Console.ReadLine());
                                            Console.WriteLine("Minutes: ");
                                            int startTimeMinutes = int.Parse(Console.ReadLine());
                                            Console.WriteLine($"{dayOfDive}/{monthOfDive}/{yearOfDive} {startTimeHours}:{startTimeMinutes}:00");
                                            Console.WriteLine("Enter end time: ");
                                            int endTimeHours = int.Parse(Console.ReadLine());
                                            Console.WriteLine("Minutes");
                                            int endTimeMinutes = int.Parse(Console.ReadLine());
                                            TimeSpan startTime = new TimeSpan(startTimeHours, startTimeMinutes, 0);
                                            TimeSpan endTime = new TimeSpan(endTimeHours, endTimeMinutes, 0);

                                            Console.WriteLine($"Confirm of diving made by Instructor {masterDiver.GetFirstName()}");
                                            Console.Clear();
                                            Console.WriteLine("Press 1 to add gear or 0 to continue");
                                            int choiceGear = int.Parse(Console.ReadLine());
                                            DiveLog newActivity = new DiveLog(diveClub1, dateOfDive, startTime, endTime, waterTemp, tide, masterDiver, diversInDive);
                                            switch (choiceGear)
                                            {
                                                case 0:
                                                    Console.WriteLine("");
                                                    break;
                                                case 1:
                                                    foreach (KeyValuePair<int, string> kvp in gears)
                                                    {
                                                        Console.WriteLine(kvp.Key + ": " + kvp.Value);
                                                    }
                                                    int gearChoice = int.Parse(Console.ReadLine());
                                                    Console.WriteLine($"Enter amount of {gears[gearChoice]} youd like to take");
                                                    string amountOfGear = Console.ReadLine();
                                                    Console.WriteLine("Do you have any notes to add to this dive?");
                                                    string notes = "";
                                                    try
                                                    {
                                                        notes = Console.ReadLine();

                                                    }
                                                    catch (FormatException e)
                                                    {
                                                        notes = "";
                                                    }
                                                    gearInDive.Add(gears[gearChoice],new []{ amountOfGear, notes }); // adds to dictionary the gear's name , then creates new array with values of amount of gear (string) and notes(string)
                                                    foreach (KeyValuePair<string, string[]> kvp in gearInDive)
                                                    {
                                                        Console.WriteLine(kvp.Key + ": " + kvp.Value[0]);
                                                        Console.WriteLine(kvp.Value[1]);
                                                    }
                                                    break;


                                            }

                                            break;
                                        case (2):
                                            AddDiveClub();
                                            Console.Clear();
                                            break;
                                        case (3):
                                            AddDivingPartner();

                                            break;
                                        case (4):
                                            break;
                                        case (5):
                                            return;

                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Incorrect login, press any key to try again.");
                            }
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                        case (2):
                            Console.Write("Welcome, fill in the following:\nEnter your name:");
                            string diverFirstName = Console.ReadLine();
                            Console.Write("last name:");
                            string diverLastName = Console.ReadLine();
                            Console.Write("ID number (make sure to have at least 6 characters):");
                            string diverId = (Console.ReadLine());
                            Console.WriteLine("Enter Birth date:");
                            Console.Write("yyyy: ");
                            int year = int.Parse(Console.ReadLine());
                            Console.Write("mm: ");
                            int month = int.Parse(Console.ReadLine());
                            Console.Write("dd: ");
                            int day = int.Parse(Console.ReadLine());
                            DateTime date = new DateTime(year, month, day);
                            Console.Write("Choose a password (8-digits or more: ");
                            string password = Console.ReadLine();
                            Console.WriteLine("Enter valid mail");
                            string mail = Console.ReadLine();
                            if (diverId.Length < 6)
                            {
                                Console.Write("* Id too short,\n");
                                return;
                            }
                            if (password.Length < 8)
                            {
                                Console.Write("* Password too short,\n");
                            }
                            if (year < 1903 || month < 1 || month > 12 || day < 1 || day > 31)
                            {
                                Console.WriteLine("* Birthday input was not in correct format");
                            }
                            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                            Match match = regex.Match(mail);
                            if (!match.Success)
                                Console.WriteLine("* Mail was insert in a wrong format");
                            if (registeredDivers.ContainsKey(diverId))
                            {
                                Console.WriteLine("Id is alredy exists in the system. Try another.");
                                break;
                            }

                            // Create a new Diver object
                            Diver newDiver = new Diver(diverId, diverFirstName, diverLastName, mail, password, date);
                            diverList.Add(newDiver);
                            registeredDivers.Add(diverId, newDiver);
                            Console.WriteLine($"{diverFirstName},{diverId} successfully registered");
                            Thread.Sleep(1200);
                            Console.Clear();
                            break;

                    }
                    //Console.WriteLine($"Diver:{mainDiver}\t\t\t\t\t Club name:{clubName}\t\t\t\t\t Dive partnerners:{divePartners}");
                    ShowMenu();
                    select = int.Parse(Console.ReadLine());
                }
            }
        }
        public static void ShowMenu()
        {
            Console.WriteLine($"Diver:{mainDiver}\t\t\tClub name:{clubName}\t\t\tDive partnerners:{divePartners}");
            Console.WriteLine("Welcome to ProDiver 1.0\n======================\nSelect:\n1.Log-in\n2.Register\n0.Exit");
        }
        public static bool LogingValidateIsInSystem(Diver diver, string id, string password)
        {
            // checks if the id and password are exists in the list.
            while (diverList != null)
            {
                if (diver.GetId() == id && diver.GetPass() == password)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool Login()
        {
            Console.Write("Enter Id:");
            string id = (Console.ReadLine());
            Console.Write("Enter password:");
            string pword = Console.ReadLine();
            if (registeredDivers.ContainsKey(id))
            {
                if (registeredDivers[id].GetPass() == pword)
                {
                    mainDiver = registeredDivers[id].GetFirstName();
                    diversInDive.Add(registeredDivers[id]);
                    Console.WriteLine($"\nWelcome {registeredDivers[id].GetFirstName()}");
                    Thread.Sleep(1000);
                    Console.Clear();
                    return true;
                }
                else
                {
                    Console.WriteLine("somthing went wrong,try again.");
                    Thread.Sleep(1000);
                    Console.Clear();
                    return false;
                }
            }
            else
            {
                Console.WriteLine("No id to be found.Sure you dont miss an identifier?");
                Thread.Sleep(1000);
                Console.Clear();
                return false;
            }

        }

        public static void ShowDiverMenu()
        {
            Console.WriteLine($"Diver:{mainDiver}\t\t\t\t\t Club name:{clubName}\t\t\t\t\t Dive partnerners:{divePartners}\n");
            Console.WriteLine(@"
Press to continue:
1)Add Dive
2)Enter DiveClub
3)Add Diving Partner/s
4)Display Diving regualtions By Country
5)Login menu");
        }
        public static bool ValidAddDive()
        {
            return mainDiver == "NULL" || clubName == "NULL"|| divePartners==0;
        }
        public static void AddDivingPartner()
        {

            Console.Write("Partner id: ");
            string partnerId = Console.ReadLine();
            Console.WriteLine("Partner password: ");
            string partnerPassword = Console.ReadLine();
            if (registeredDivers.ContainsKey(partnerId))
            {
                if (registeredDivers[partnerId].GetPass() == partnerPassword)
                {
                    divePartners++;
                    diversInDive.Add(registeredDivers[partnerId]);
                    Console.WriteLine($"Welcome {registeredDivers[partnerId].GetFirstName()}");
                    Thread.Sleep(1000); Console.Clear();
                    //ShowDiverMenu();
                }
                else
                {
                    Console.WriteLine("somthing went wrong,try again.");
                    //return false;
                }
            }
            else
            {
                Console.WriteLine("No id to be found.Sure you dont miss an identifier?");
                Console.Clear();
            }
            //registeredDivers.Add(partnerId, newDiver); // 
        }
        public static void AddDiveClub()
        {
            string[] arrayOfClubs = new string[] { "BrazilDive", "EilatDive", "AcreDiveClub", "KazakhstanDivers", "LatviaScubaz", "WestMalaysiaDC", "EastMalaysiaDC", "Blue Lagoon", "ThaiDive" };
            Console.WriteLine("Enter Dive club name OR enter country name(type 'list' to show all dive clubs)");
            string diveClubChoice = Console.ReadLine();
            diveClubChoice.ToLower();
            if (diveClubChoice == "list")
            {
                Console.WriteLine(@"Enter the club index you wish to dive from:

Club                    Country
-------------------------------
1)BrazilDive            Brazil
2)EilatDive             Israel
3)AcreDiveClub          Israel
4)KazakhstanDivers              Kazakhstan
5)LatviaScubaz          Latvia
6)WestMalaysiaDC                Malaysia
7)EastMalaysiaDC                Malaysia
8)Blue Lagoon           Mexico
9)ThaiDive              Thailand");
                int index = int.Parse(Console.ReadLine());
                while (index < 0 || index > 10)
                {
                    Console.WriteLine("Invalid input. try again.");
                    index = int.Parse(Console.ReadLine());
                }
                clubName = arrayOfClubs[index - 1];
                Console.WriteLine($"you have choose {clubName}");
            }
        }
    }
}


